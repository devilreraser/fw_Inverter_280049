################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Each subdirectory must supply rules for building sources it contributes
MCAL_F2800049C/f28004x_adc.obj: C:/ti/c2000/C2000Ware_6_00_00_00/device_support/f28004x/common/source/f28004x_adc.c $(GEN_OPTS) | $(GEN_FILES) $(GEN_MISC_FILES)
	@echo 'Building file: "$<"'
	@echo 'Invoking: C2000 Compiler'
	"C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/bin/cl2000" -v28 -ml -mt --cla_support=cla2 --float_support=fpu32 --tmu_support=tmu0 --vcu_support=vcu0 -O2 --include_path="C:/repo/fw_Inverter_280049/05_Project/DTP_F280049/DTP_280049" --include_path="C:/ti/c2000/C2000Ware_6_00_00_00/device_support/f28004x/headers/include" --include_path="C:/ti/c2000/C2000Ware_6_00_00_00/device_support/f28004x/common/include" --include_path="C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include" --define=_FLASH --diag_warning=225 --diag_wrap=off --display_error_number --abi=coffabi --preproc_with_compile --preproc_dependency="MCAL_F2800049C/$(basename $(<F)).d_raw" --obj_directory="MCAL_F2800049C" $(GEN_OPTS__FLAG) "$<"
	@echo 'Finished building: "$<"'
	@echo ' '

MCAL_F2800049C/f28004x_codestartbranch.obj: C:/ti/c2000/C2000Ware_6_00_00_00/device_support/f28004x/common/source/f28004x_codestartbranch.asm $(GEN_OPTS) | $(GEN_FILES) $(GEN_MISC_FILES)
	@echo 'Building file: "$<"'
	@echo 'Invoking: C2000 Compiler'
	"C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/bin/cl2000" -v28 -ml -mt --cla_support=cla2 --float_support=fpu32 --tmu_support=tmu0 --vcu_support=vcu0 -O2 --include_path="C:/repo/fw_Inverter_280049/05_Project/DTP_F280049/DTP_280049" --include_path="C:/ti/c2000/C2000Ware_6_00_00_00/device_support/f28004x/headers/include" --include_path="C:/ti/c2000/C2000Ware_6_00_00_00/device_support/f28004x/common/include" --include_path="C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include" --define=_FLASH --diag_warning=225 --diag_wrap=off --display_error_number --abi=coffabi --preproc_with_compile --preproc_dependency="MCAL_F2800049C/$(basename $(<F)).d_raw" --obj_directory="MCAL_F2800049C" $(GEN_OPTS__FLAG) "$<"
	@echo 'Finished building: "$<"'
	@echo ' '

MCAL_F2800049C/f28004x_defaultisr.obj: C:/ti/c2000/C2000Ware_6_00_00_00/device_support/f28004x/common/source/f28004x_defaultisr.c $(GEN_OPTS) | $(GEN_FILES) $(GEN_MISC_FILES)
	@echo 'Building file: "$<"'
	@echo 'Invoking: C2000 Compiler'
	"C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/bin/cl2000" -v28 -ml -mt --cla_support=cla2 --float_support=fpu32 --tmu_support=tmu0 --vcu_support=vcu0 -O2 --include_path="C:/repo/fw_Inverter_280049/05_Project/DTP_F280049/DTP_280049" --include_path="C:/ti/c2000/C2000Ware_6_00_00_00/device_support/f28004x/headers/include" --include_path="C:/ti/c2000/C2000Ware_6_00_00_00/device_support/f28004x/common/include" --include_path="C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include" --define=_FLASH --diag_warning=225 --diag_wrap=off --display_error_number --abi=coffabi --preproc_with_compile --preproc_dependency="MCAL_F2800049C/$(basename $(<F)).d_raw" --obj_directory="MCAL_F2800049C" $(GEN_OPTS__FLAG) "$<"
	@echo 'Finished building: "$<"'
	@echo ' '

MCAL_F2800049C/f28004x_globalvariabledefs.obj: C:/ti/c2000/C2000Ware_6_00_00_00/device_support/f28004x/headers/source/f28004x_globalvariabledefs.c $(GEN_OPTS) | $(GEN_FILES) $(GEN_MISC_FILES)
	@echo 'Building file: "$<"'
	@echo 'Invoking: C2000 Compiler'
	"C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/bin/cl2000" -v28 -ml -mt --cla_support=cla2 --float_support=fpu32 --tmu_support=tmu0 --vcu_support=vcu0 -O2 --include_path="C:/repo/fw_Inverter_280049/05_Project/DTP_F280049/DTP_280049" --include_path="C:/ti/c2000/C2000Ware_6_00_00_00/device_support/f28004x/headers/include" --include_path="C:/ti/c2000/C2000Ware_6_00_00_00/device_support/f28004x/common/include" --include_path="C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include" --define=_FLASH --diag_warning=225 --diag_wrap=off --display_error_number --abi=coffabi --preproc_with_compile --preproc_dependency="MCAL_F2800049C/$(basename $(<F)).d_raw" --obj_directory="MCAL_F2800049C" $(GEN_OPTS__FLAG) "$<"
	@echo 'Finished building: "$<"'
	@echo ' '

MCAL_F2800049C/f28004x_gpio.obj: C:/ti/c2000/C2000Ware_6_00_00_00/device_support/f28004x/common/source/f28004x_gpio.c $(GEN_OPTS) | $(GEN_FILES) $(GEN_MISC_FILES)
	@echo 'Building file: "$<"'
	@echo 'Invoking: C2000 Compiler'
	"C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/bin/cl2000" -v28 -ml -mt --cla_support=cla2 --float_support=fpu32 --tmu_support=tmu0 --vcu_support=vcu0 -O2 --include_path="C:/repo/fw_Inverter_280049/05_Project/DTP_F280049/DTP_280049" --include_path="C:/ti/c2000/C2000Ware_6_00_00_00/device_support/f28004x/headers/include" --include_path="C:/ti/c2000/C2000Ware_6_00_00_00/device_support/f28004x/common/include" --include_path="C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include" --define=_FLASH --diag_warning=225 --diag_wrap=off --display_error_number --abi=coffabi --preproc_with_compile --preproc_dependency="MCAL_F2800049C/$(basename $(<F)).d_raw" --obj_directory="MCAL_F2800049C" $(GEN_OPTS__FLAG) "$<"
	@echo 'Finished building: "$<"'
	@echo ' '

MCAL_F2800049C/f28004x_piectrl.obj: C:/ti/c2000/C2000Ware_6_00_00_00/device_support/f28004x/common/source/f28004x_piectrl.c $(GEN_OPTS) | $(GEN_FILES) $(GEN_MISC_FILES)
	@echo 'Building file: "$<"'
	@echo 'Invoking: C2000 Compiler'
	"C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/bin/cl2000" -v28 -ml -mt --cla_support=cla2 --float_support=fpu32 --tmu_support=tmu0 --vcu_support=vcu0 -O2 --include_path="C:/repo/fw_Inverter_280049/05_Project/DTP_F280049/DTP_280049" --include_path="C:/ti/c2000/C2000Ware_6_00_00_00/device_support/f28004x/headers/include" --include_path="C:/ti/c2000/C2000Ware_6_00_00_00/device_support/f28004x/common/include" --include_path="C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include" --define=_FLASH --diag_warning=225 --diag_wrap=off --display_error_number --abi=coffabi --preproc_with_compile --preproc_dependency="MCAL_F2800049C/$(basename $(<F)).d_raw" --obj_directory="MCAL_F2800049C" $(GEN_OPTS__FLAG) "$<"
	@echo 'Finished building: "$<"'
	@echo ' '

MCAL_F2800049C/f28004x_pievect.obj: C:/ti/c2000/C2000Ware_6_00_00_00/device_support/f28004x/common/source/f28004x_pievect.c $(GEN_OPTS) | $(GEN_FILES) $(GEN_MISC_FILES)
	@echo 'Building file: "$<"'
	@echo 'Invoking: C2000 Compiler'
	"C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/bin/cl2000" -v28 -ml -mt --cla_support=cla2 --float_support=fpu32 --tmu_support=tmu0 --vcu_support=vcu0 -O2 --include_path="C:/repo/fw_Inverter_280049/05_Project/DTP_F280049/DTP_280049" --include_path="C:/ti/c2000/C2000Ware_6_00_00_00/device_support/f28004x/headers/include" --include_path="C:/ti/c2000/C2000Ware_6_00_00_00/device_support/f28004x/common/include" --include_path="C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include" --define=_FLASH --diag_warning=225 --diag_wrap=off --display_error_number --abi=coffabi --preproc_with_compile --preproc_dependency="MCAL_F2800049C/$(basename $(<F)).d_raw" --obj_directory="MCAL_F2800049C" $(GEN_OPTS__FLAG) "$<"
	@echo 'Finished building: "$<"'
	@echo ' '

MCAL_F2800049C/f28004x_sysctrl.obj: C:/ti/c2000/C2000Ware_6_00_00_00/device_support/f28004x/common/source/f28004x_sysctrl.c $(GEN_OPTS) | $(GEN_FILES) $(GEN_MISC_FILES)
	@echo 'Building file: "$<"'
	@echo 'Invoking: C2000 Compiler'
	"C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/bin/cl2000" -v28 -ml -mt --cla_support=cla2 --float_support=fpu32 --tmu_support=tmu0 --vcu_support=vcu0 -O2 --include_path="C:/repo/fw_Inverter_280049/05_Project/DTP_F280049/DTP_280049" --include_path="C:/ti/c2000/C2000Ware_6_00_00_00/device_support/f28004x/headers/include" --include_path="C:/ti/c2000/C2000Ware_6_00_00_00/device_support/f28004x/common/include" --include_path="C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include" --define=_FLASH --diag_warning=225 --diag_wrap=off --display_error_number --abi=coffabi --preproc_with_compile --preproc_dependency="MCAL_F2800049C/$(basename $(<F)).d_raw" --obj_directory="MCAL_F2800049C" $(GEN_OPTS__FLAG) "$<"
	@echo 'Finished building: "$<"'
	@echo ' '

MCAL_F2800049C/f28004x_usdelay.obj: C:/ti/c2000/C2000Ware_6_00_00_00/device_support/f28004x/common/source/f28004x_usdelay.asm $(GEN_OPTS) | $(GEN_FILES) $(GEN_MISC_FILES)
	@echo 'Building file: "$<"'
	@echo 'Invoking: C2000 Compiler'
	"C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/bin/cl2000" -v28 -ml -mt --cla_support=cla2 --float_support=fpu32 --tmu_support=tmu0 --vcu_support=vcu0 -O2 --include_path="C:/repo/fw_Inverter_280049/05_Project/DTP_F280049/DTP_280049" --include_path="C:/ti/c2000/C2000Ware_6_00_00_00/device_support/f28004x/headers/include" --include_path="C:/ti/c2000/C2000Ware_6_00_00_00/device_support/f28004x/common/include" --include_path="C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include" --define=_FLASH --diag_warning=225 --diag_wrap=off --display_error_number --abi=coffabi --preproc_with_compile --preproc_dependency="MCAL_F2800049C/$(basename $(<F)).d_raw" --obj_directory="MCAL_F2800049C" $(GEN_OPTS__FLAG) "$<"
	@echo 'Finished building: "$<"'
	@echo ' '


