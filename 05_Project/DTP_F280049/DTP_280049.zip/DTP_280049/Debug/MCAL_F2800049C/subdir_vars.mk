################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
CMD_SRCS += \
C:/ti/c2000/C2000Ware_6_00_00_00/device_support/f28004x/headers/cmd/f28004x_headers_nonbios.cmd 

ASM_SRCS += \
C:/ti/c2000/C2000Ware_6_00_00_00/device_support/f28004x/common/source/f28004x_codestartbranch.asm \
C:/ti/c2000/C2000Ware_6_00_00_00/device_support/f28004x/common/source/f28004x_usdelay.asm 

C_SRCS += \
C:/ti/c2000/C2000Ware_6_00_00_00/device_support/f28004x/common/source/f28004x_adc.c \
C:/ti/c2000/C2000Ware_6_00_00_00/device_support/f28004x/common/source/f28004x_defaultisr.c \
C:/ti/c2000/C2000Ware_6_00_00_00/device_support/f28004x/headers/source/f28004x_globalvariabledefs.c \
C:/ti/c2000/C2000Ware_6_00_00_00/device_support/f28004x/common/source/f28004x_gpio.c \
C:/ti/c2000/C2000Ware_6_00_00_00/device_support/f28004x/common/source/f28004x_piectrl.c \
C:/ti/c2000/C2000Ware_6_00_00_00/device_support/f28004x/common/source/f28004x_pievect.c \
C:/ti/c2000/C2000Ware_6_00_00_00/device_support/f28004x/common/source/f28004x_sysctrl.c 

C_DEPS += \
./MCAL_F2800049C/f28004x_adc.d \
./MCAL_F2800049C/f28004x_defaultisr.d \
./MCAL_F2800049C/f28004x_globalvariabledefs.d \
./MCAL_F2800049C/f28004x_gpio.d \
./MCAL_F2800049C/f28004x_piectrl.d \
./MCAL_F2800049C/f28004x_pievect.d \
./MCAL_F2800049C/f28004x_sysctrl.d 

OBJS += \
./MCAL_F2800049C/f28004x_adc.obj \
./MCAL_F2800049C/f28004x_codestartbranch.obj \
./MCAL_F2800049C/f28004x_defaultisr.obj \
./MCAL_F2800049C/f28004x_globalvariabledefs.obj \
./MCAL_F2800049C/f28004x_gpio.obj \
./MCAL_F2800049C/f28004x_piectrl.obj \
./MCAL_F2800049C/f28004x_pievect.obj \
./MCAL_F2800049C/f28004x_sysctrl.obj \
./MCAL_F2800049C/f28004x_usdelay.obj 

ASM_DEPS += \
./MCAL_F2800049C/f28004x_codestartbranch.d \
./MCAL_F2800049C/f28004x_usdelay.d 

OBJS__QUOTED += \
"MCAL_F2800049C\f28004x_adc.obj" \
"MCAL_F2800049C\f28004x_codestartbranch.obj" \
"MCAL_F2800049C\f28004x_defaultisr.obj" \
"MCAL_F2800049C\f28004x_globalvariabledefs.obj" \
"MCAL_F2800049C\f28004x_gpio.obj" \
"MCAL_F2800049C\f28004x_piectrl.obj" \
"MCAL_F2800049C\f28004x_pievect.obj" \
"MCAL_F2800049C\f28004x_sysctrl.obj" \
"MCAL_F2800049C\f28004x_usdelay.obj" 

C_DEPS__QUOTED += \
"MCAL_F2800049C\f28004x_adc.d" \
"MCAL_F2800049C\f28004x_defaultisr.d" \
"MCAL_F2800049C\f28004x_globalvariabledefs.d" \
"MCAL_F2800049C\f28004x_gpio.d" \
"MCAL_F2800049C\f28004x_piectrl.d" \
"MCAL_F2800049C\f28004x_pievect.d" \
"MCAL_F2800049C\f28004x_sysctrl.d" 

ASM_DEPS__QUOTED += \
"MCAL_F2800049C\f28004x_codestartbranch.d" \
"MCAL_F2800049C\f28004x_usdelay.d" 

C_SRCS__QUOTED += \
"C:/ti/c2000/C2000Ware_6_00_00_00/device_support/f28004x/common/source/f28004x_adc.c" \
"C:/ti/c2000/C2000Ware_6_00_00_00/device_support/f28004x/common/source/f28004x_defaultisr.c" \
"C:/ti/c2000/C2000Ware_6_00_00_00/device_support/f28004x/headers/source/f28004x_globalvariabledefs.c" \
"C:/ti/c2000/C2000Ware_6_00_00_00/device_support/f28004x/common/source/f28004x_gpio.c" \
"C:/ti/c2000/C2000Ware_6_00_00_00/device_support/f28004x/common/source/f28004x_piectrl.c" \
"C:/ti/c2000/C2000Ware_6_00_00_00/device_support/f28004x/common/source/f28004x_pievect.c" \
"C:/ti/c2000/C2000Ware_6_00_00_00/device_support/f28004x/common/source/f28004x_sysctrl.c" 

ASM_SRCS__QUOTED += \
"C:/ti/c2000/C2000Ware_6_00_00_00/device_support/f28004x/common/source/f28004x_codestartbranch.asm" \
"C:/ti/c2000/C2000Ware_6_00_00_00/device_support/f28004x/common/source/f28004x_usdelay.asm" 


