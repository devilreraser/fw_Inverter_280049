################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
CMD_SRCS += \
C:/ti/c2000/C2000Ware_6_00_00_00/device_support/f2837xd/headers/cmd/F2837xD_Headers_nonBIOS_cpu1.cmd 

ASM_SRCS += \
C:/ti/c2000/C2000Ware_6_00_00_00/device_support/f2837xd/common/source/F2837xD_CodeStartBranch.asm \
C:/ti/c2000/C2000Ware_6_00_00_00/device_support/f2837xd/common/source/F2837xD_usDelay.asm 

C_SRCS += \
C:/ti/c2000/C2000Ware_6_00_00_00/device_support/f2837xd/common/source/F2837xD_Adc.c \
C:/ti/c2000/C2000Ware_6_00_00_00/device_support/f2837xd/common/source/F2837xD_DefaultISR.c \
C:/ti/c2000/C2000Ware_6_00_00_00/device_support/f2837xd/headers/source/F2837xD_GlobalVariableDefs.c \
C:/ti/c2000/C2000Ware_6_00_00_00/device_support/f2837xd/common/source/F2837xD_Gpio.c \
C:/ti/c2000/C2000Ware_6_00_00_00/device_support/f2837xd/common/source/F2837xD_PieCtrl.c \
C:/ti/c2000/C2000Ware_6_00_00_00/device_support/f2837xd/common/source/F2837xD_PieVect.c \
C:/ti/c2000/C2000Ware_6_00_00_00/device_support/f2837xd/common/source/F2837xD_SysCtrl.c 

C_DEPS += \
./MCAL_F28379D/F2837xD_Adc.d \
./MCAL_F28379D/F2837xD_DefaultISR.d \
./MCAL_F28379D/F2837xD_GlobalVariableDefs.d \
./MCAL_F28379D/F2837xD_Gpio.d \
./MCAL_F28379D/F2837xD_PieCtrl.d \
./MCAL_F28379D/F2837xD_PieVect.d \
./MCAL_F28379D/F2837xD_SysCtrl.d 

OBJS += \
./MCAL_F28379D/F2837xD_Adc.obj \
./MCAL_F28379D/F2837xD_CodeStartBranch.obj \
./MCAL_F28379D/F2837xD_DefaultISR.obj \
./MCAL_F28379D/F2837xD_GlobalVariableDefs.obj \
./MCAL_F28379D/F2837xD_Gpio.obj \
./MCAL_F28379D/F2837xD_PieCtrl.obj \
./MCAL_F28379D/F2837xD_PieVect.obj \
./MCAL_F28379D/F2837xD_SysCtrl.obj \
./MCAL_F28379D/F2837xD_usDelay.obj 

ASM_DEPS += \
./MCAL_F28379D/F2837xD_CodeStartBranch.d \
./MCAL_F28379D/F2837xD_usDelay.d 

OBJS__QUOTED += \
"MCAL_F28379D\F2837xD_Adc.obj" \
"MCAL_F28379D\F2837xD_CodeStartBranch.obj" \
"MCAL_F28379D\F2837xD_DefaultISR.obj" \
"MCAL_F28379D\F2837xD_GlobalVariableDefs.obj" \
"MCAL_F28379D\F2837xD_Gpio.obj" \
"MCAL_F28379D\F2837xD_PieCtrl.obj" \
"MCAL_F28379D\F2837xD_PieVect.obj" \
"MCAL_F28379D\F2837xD_SysCtrl.obj" \
"MCAL_F28379D\F2837xD_usDelay.obj" 

C_DEPS__QUOTED += \
"MCAL_F28379D\F2837xD_Adc.d" \
"MCAL_F28379D\F2837xD_DefaultISR.d" \
"MCAL_F28379D\F2837xD_GlobalVariableDefs.d" \
"MCAL_F28379D\F2837xD_Gpio.d" \
"MCAL_F28379D\F2837xD_PieCtrl.d" \
"MCAL_F28379D\F2837xD_PieVect.d" \
"MCAL_F28379D\F2837xD_SysCtrl.d" 

ASM_DEPS__QUOTED += \
"MCAL_F28379D\F2837xD_CodeStartBranch.d" \
"MCAL_F28379D\F2837xD_usDelay.d" 

C_SRCS__QUOTED += \
"C:/ti/c2000/C2000Ware_6_00_00_00/device_support/f2837xd/common/source/F2837xD_Adc.c" \
"C:/ti/c2000/C2000Ware_6_00_00_00/device_support/f2837xd/common/source/F2837xD_DefaultISR.c" \
"C:/ti/c2000/C2000Ware_6_00_00_00/device_support/f2837xd/headers/source/F2837xD_GlobalVariableDefs.c" \
"C:/ti/c2000/C2000Ware_6_00_00_00/device_support/f2837xd/common/source/F2837xD_Gpio.c" \
"C:/ti/c2000/C2000Ware_6_00_00_00/device_support/f2837xd/common/source/F2837xD_PieCtrl.c" \
"C:/ti/c2000/C2000Ware_6_00_00_00/device_support/f2837xd/common/source/F2837xD_PieVect.c" \
"C:/ti/c2000/C2000Ware_6_00_00_00/device_support/f2837xd/common/source/F2837xD_SysCtrl.c" 

ASM_SRCS__QUOTED += \
"C:/ti/c2000/C2000Ware_6_00_00_00/device_support/f2837xd/common/source/F2837xD_CodeStartBranch.asm" \
"C:/ti/c2000/C2000Ware_6_00_00_00/device_support/f2837xd/common/source/F2837xD_usDelay.asm" 


